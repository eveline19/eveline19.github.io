<!DOCTYPE html>
<html>
    <head>
        <title>LATIHAN 5 PEMROGRAMAN WEB</title>
    </head>
    <body>
        <?php
            $nim = "2105101019";
            $nama = "Valliant Dheka F"; 
            $angka1 = 23; 
            $angka2 = 12;

            $hasilpenjumlahan = $angka1 + $angka2;

            echo "NIM : ". $nim . "<br/>";
            echo "NAMA : ". $nama . "<br/>";
            echo "Hasil Penjumlahan dari : " . $angka1 ." + ". $angka2 . " = " . $hasilpenjumlahan . "<br/>";
        ?>
    </body>
</html>