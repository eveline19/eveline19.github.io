<!DOCTYPE html>
<html>
    <head>
        <title>LATIHAN 4 PEMROGRAMAN WEB</title>
    </head>
    <body>
        <?php
            $bilanganbulat = 17; // nilai variabel yang  berisi angka (integer)
            $teks = "aku"; // nilai variabel yang  berisi kata (string)
            $bilangandesimal = 17.42; // nilai variabel yang  berisi angka desimal (float)

            echo "Nilai variabel bilanganbulat : ". $bilanganbulat . "<br/>";
            echo "Nilai variabel teks : ". $teks . "<br/>";
            echo "Nilai variabel bilangandesimal : ". $bilangandesimal . "<br/>";
        ?>
    </body>
</html>