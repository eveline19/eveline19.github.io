<!DOCTYPE html>
<html>
    <head>
        <title>LATIHAN 3 PEMROGRAMAN WEB</title>
    </head>
    <body>
        <font color ="red">
            <?php echo "Tulisan ini berwarna merah"; ?>
        </font>

        <?php
            echo "
                <br/>
                <b>Tulisan dalam bold tau tulisan tebal</b>
            ";
        ?>
    </body>
</html>